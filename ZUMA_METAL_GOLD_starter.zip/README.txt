ZUMA METAL GOLD — starter prototype

Open index.html in a browser to preview the mobile-friendly marketplace prototype.

Included:
- Home page and demo bullion catalogue
- Sell-gold enquiry form (local demo only)
- Preview navigation for account and orders

Not included:
- Live gold pricing
- Real accounts or database
- Payments, customer wallet, or withdrawals
- Real order submission, inventory, or shipping

Do not accept customer funds or promise gold delivery using this prototype.
Before launch, obtain legal advice on applicable Nigerian/Ghanaian gold trading,
AML/KYC, export, consumer protection, data protection and payment/wallet rules.
